import \{ motion \} from 'framer-motion';
import \{ Link \} from 'react-router-dom';
import \{ Heart, Target, Rocket, Users, Award, Coffee, Instagram, Mail \} from 'lucide-react';
import GlowButton from '../components/GlowButton';

export default function About() \{
  const values = [
    \{
      icon: Target,
      title: 'Quality First',
      description: 'We never compromise on quality. Every project gets our full attention and creative energy.',
      color: 'from-cyan-400 to-blue-500',
    \},
    \{
      icon: Rocket,
      title: 'Fast Delivery',
      description: 'We understand the creator economy moves fast. Quick turnarounds without sacrificing quality.',
      color: 'from-purple-400 to-pink-500',
    \},
    \{
      icon: Heart,
      title: 'Passion Driven',
      description: 'We love what we do. Your success is our success, and we genuinely care about your growth.',
      color: 'from-pink-400 to-rose-500',
    \},
    \{
      icon: Users,
      title: 'Creator Focused',
      description: 'Built by creators, for creators. We understand your needs because we\'ve been there.',
      color: 'from-yellow-400 to-orange-500',
    \},
  ];

  const milestones = [
    \{ year: '2022', title: 'Started', description: 'Began as a passion project editing reels for friends' \},
    \{ year: '2023', title: 'Growth', description: 'Expanded to 100+ clients across India' \},
    \{ year: '2024', title: 'Evolution', description: 'Added web development & full branding services' \},
    \{ year: 'Now', title: 'Future', description: 'Building the go-to creative studio for Gen Z' \},
  ];

  return (
<div classname="min-h-screen pt-20">
  \{/* Hero */\}
  <section classname="py-16 md:py-24 px-4 relative overflow-hidden">
    <div classname="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl">
      <div classname="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl">
        <div classname="max-w-7xl mx-auto relative">
          <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" animate="{{" 1,="" 0="" classname="text-center max-w-3xl mx-auto">
            <motion.div initial="{{" opacity:="" 0,="" scale:="" 0.9="" }}="" animate="{{" 1,="" 1="" transition="{{" delay:="" 0.1="" classname="inline-flex items-center gap-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full mb-6">
              <heart classname="w-4 h-4 text-purple-400">
                <span classname="text-sm text-purple-300">
                  Our Story
                </span>
              </heart>
            </motion.div>
            <h1 classname="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              <span classname="text-white">
                About
              </span>
              <span classname="bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                EditSpace
              </span>
            </h1>
            <p classname="text-xl text-gray-400">
              We're a creative studio from Kolkata, helping Gen Z creators turn their content dreams into viral reality.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  </section>
  \{/* Story Section */\}
  <section classname="py-16 px-4">
    <div classname="max-w-7xl mx-auto">
      <div classname="grid lg:grid-cols-2 gap-12 items-center">
        <motion.div initial="{{" opacity:="" 0,="" x:="" -30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="">
          <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-6">
            From a Bedroom Studio to\{' '\}
            <span classname="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              500+ Projects
            </span>
          </h2>
          <div classname="space-y-4 text-gray-400">
            <p>
              EditSpace started in 2022 when our founder, a content creator himself, realized how hard it was 
                  to find affordable, quality editing services that actually understood Gen Z aesthetics.
            </p>
            <p>
              What began as editing reels for friends quickly grew into something bigger. Creators started 
                  noticing the difference – the trendy transitions, the perfect music sync, the scroll-stopping 
                  thumbnails.
            </p>
            <p>
              Today, we're proud to have helped 100+ creators across India grow their audience with content 
                  that stands out. From Instagram influencers to YouTube educators, we've worked with creators 
                  of all sizes.
            </p>
            <p classname="text-white font-medium">
              Our mission? Make professional-quality content accessible to every creator, regardless of budget.
            </p>
          </div>
        </motion.div>
        <motion.div initial="{{" opacity:="" 0,="" x:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="relative">
          <div classname="aspect-square rounded-3xl overflow-hidden bg-gradient-to-br from-cyan-500/20 via-purple-500/20 to-pink-500/20 border border-white/10">
            <img src="/images/portfolio-1.jpg" alt="EditSpace Studio" classname="w-full h-full object-cover opacity-80" />
            <div classname="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent">
              <div classname="absolute bottom-6 left-6 right-6">
                <div classname="flex items-center gap-3">
                  <div classname="w-12 h-12 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 flex items-center justify-center">
                    <coffee classname="w-6 h-6 text-white">
                    </coffee>
                  </div>
                  <div>
                    <p classname="text-white font-semibold">
                      Fueled by Chai & Creativity
                    </p>
                    <p classname="text-gray-400 text-sm">
                      Kolkata, India
                    </p>
                  </div>
                </div>
              </div>
            </div>
            \{/* Floating stats */\}
            <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" 0.3="" classname="absolute -bottom-6 -left-6 p-4 bg-black/80 backdrop-blur-xl border border-cyan-500/30 rounded-2xl">
              <div classname="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                500+
              </div>
              <div classname="text-gray-400 text-sm">
                Projects Delivered
              </div>
            </motion.div>
            <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" 0.4="" classname="absolute -top-6 -right-6 p-4 bg-black/80 backdrop-blur-xl border border-pink-500/30 rounded-2xl">
              <div classname="text-3xl font-bold bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent">
                4.9★
              </div>
              <div classname="text-gray-400 text-sm">
                Client Rating
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
  \{/* Values */\}
  <section classname="py-20 px-4 relative">
    <div classname="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-purple-500/5 to-pink-500/5">
      <div classname="max-w-7xl mx-auto relative">
        <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-16">
          <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
            What We\{' '\}
            <span classname="bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent">
              Stand For
            </span>
          </h2>
        </motion.div>
        <div classname="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          \{values.map((value, index) => (
          <motion.div key="{index}" initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.1="" whilehover="{{" -10="" classname="group p-6 bg-black/50 border border-white/10 rounded-2xl hover:border-white/20 transition-all text-center">
            <div classname="{`w-16" h-16="" mx-auto="" rounded-2xl="" bg-gradient-to-r="" ${value.color}="" flex="" items-center="" justify-center="" mb-6="" group-hover:scale-110="" transition-transform`}="">
              <value.icon classname="w-8 h-8 text-white">
              </value.icon>
            </div>
            <h3 classname="text-xl font-bold text-white mb-3">
              \{value.title\}
            </h3>
            <p classname="text-gray-400 text-sm">
              \{value.description\}
            </p>
          </motion.div>
          ))\}
        </div>
      </div>
    </div>
  </section>
  \{/* Timeline */\}
  <section classname="py-20 px-4">
    <div classname="max-w-4xl mx-auto">
      <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-16">
        <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
          Our\{' '\}
          <span classname="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
            Journey
          </span>
        </h2>
      </motion.div>
      <div classname="relative">
        \{/* Timeline line */\}
        <div classname="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-500 via-purple-500 to-pink-500">
          \{milestones.map((milestone, index) => (
          <motion.div key="{index}" initial="{{" opacity:="" 0,="" x:="" index="" %="" 2="==" 0="" ?="" -30="" :="" 30="" }}="" whileinview="{{" 1,="" viewport="{{" once:="" true="" transition="{{" delay:="" *="" 0.1="" classname="{`relative" flex="" items-center="" gap-8="" mb-12="" ${index="" 'md:flex-row'="" 'md:flex-row-reverse'}`}="">
            \{/* Content */\}
            <div classname="{`flex-1" ml-12="" md:ml-0="" ${index="" %="" 2="==" 0="" ?="" 'md:text-right'="" :="" 'md:text-left'}`}="">
              <div classname="p-6 bg-white/5 border border-white/10 rounded-2xl">
                <span classname="text-sm font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
                  \{milestone.year\}
                </span>
                <h3 classname="text-xl font-bold text-white mt-1 mb-2">
                  \{milestone.title\}
                </h3>
                <p classname="text-gray-400">
                  \{milestone.description\}
                </p>
              </div>
            </div>
            \{/* Dot */\}
            <div classname="absolute left-4 md:left-1/2 -translate-x-1/2 w-4 h-4 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full border-4 border-black">
              \{/* Spacer for alternating layout */\}
              <div classname="hidden md:block flex-1">
                ))\}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  </section>
  \{/* Achievements */\}
  <section classname="py-20 px-4">
    <div classname="max-w-7xl mx-auto">
      <div classname="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        \{[
              \{ icon: Award, value: '500+', label: 'Projects Completed' \},
              \{ icon: Users, value: '100+', label: 'Happy Creators' \},
              \{ icon: Coffee, value: '1000+', label: 'Cups of Chai' \},
              \{ icon: Heart, value: '99%', label: 'Satisfaction Rate' \},
            ].map((stat, index) => (
        <motion.div key="{index}" initial="{{" opacity:="" 0,="" scale:="" 0.9="" }}="" whileinview="{{" 1,="" 1="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.1="" classname="p-6 bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-2xl text-center">
          <stat.icon classname="w-8 h-8 mx-auto mb-4 text-cyan-400">
            <div classname="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-2">
              \{stat.value\}
            </div>
            <p classname="text-gray-400">
              \{stat.label\}
            </p>
          </stat.icon>
        </motion.div>
        ))\}
      </div>
    </div>
  </section>
  \{/* CTA */\}
  <section classname="py-20 px-4">
    <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="max-w-4xl mx-auto text-center p-8 md:p-12 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10 border border-white/10 rounded-3xl">
      <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
        Ready to Work With Us?
      </h2>
      <p classname="text-gray-400 text-lg mb-8">
        Let's create content that makes your audience stop scrolling!
      </p>
      <div classname="flex flex-col sm:flex-row gap-4 justify-center">
        <a href="https://instagram.com/editspace.in" target="_blank" rel="noopener noreferrer">
          <glowbutton size="lg">
            <instagram classname="w-5 h-5">
              DM on Instagram
            </instagram>
          </glowbutton>
        </a>
        <link to="/contact" />
        <glowbutton variant="outline" size="lg">
          <mail classname="w-5 h-5">
            Contact Us
          </mail>
        </glowbutton>
      </div>
    </motion.div>
  </section>
</div>
);
\}
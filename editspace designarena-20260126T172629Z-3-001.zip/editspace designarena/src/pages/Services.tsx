import \{ motion \} from 'framer-motion';
import \{ Link \} from 'react-router-dom';
import \{ Video, Image, Palette, Globe, Sparkles, Layers, ArrowRight, Check \} from 'lucide-react';
import GlowButton from '../components/GlowButton';

export default function Services() \{
  const services = [
    \{
      icon: Video,
      title: 'Video Editing',
      subtitle: 'Reels, Shorts & TikToks',
      description: 'Transform raw footage into viral-worthy content with trending transitions, effects, and perfect music sync.',
      features: [
        'Instagram Reels editing',
        'YouTube Shorts optimization',
        'TikTok-style transitions',
        'Color grading & correction',
        'Music sync & sound design',
        'Captions & subtitles',
      ],
      gradient: 'from-cyan-500 to-blue-600',
      price: 'Starting ₹499',
    \},
    \{
      icon: Image,
      title: 'Thumbnail Design',
      subtitle: 'Click-Worthy Thumbnails',
      description: 'Eye-catching thumbnails that boost your CTR and make viewers click instantly.',
      features: [
        'YouTube thumbnails',
        'Custom typography',
        'Face enhancement',
        'A/B testing variants',
        '3D elements',
        'Brand consistency',
      ],
      gradient: 'from-pink-500 to-rose-600',
      price: 'Starting ₹199',
    \},
    \{
      icon: Palette,
      title: 'Graphic Design',
      subtitle: 'Social Media Graphics',
      description: 'Stunning visuals for your social media presence that stop the scroll.',
      features: [
        'Instagram posts & stories',
        'Carousel designs',
        'Quote graphics',
        'Promotional banners',
        'Event posters',
        'Brand templates',
      ],
      gradient: 'from-purple-500 to-violet-600',
      price: 'Starting ₹299',
    \},
    \{
      icon: Sparkles,
      title: 'Logo & Branding',
      subtitle: 'Brand Identity',
      description: 'Create a memorable brand identity that resonates with your audience.',
      features: [
        'Logo design',
        'Brand guidelines',
        'Color palette',
        'Typography selection',
        'Social media kit',
        'Business cards',
      ],
      gradient: 'from-yellow-500 to-orange-600',
      price: 'Starting ₹1,999',
    \},
    \{
      icon: Globe,
      title: 'Website Development',
      subtitle: 'Modern Websites',
      description: 'Fast, responsive, and beautiful websites that convert visitors into followers.',
      features: [
        'Portfolio websites',
        'Landing pages',
        'Link-in-bio pages',
        'Mobile responsive',
        'SEO optimized',
        'Analytics setup',
      ],
      gradient: 'from-emerald-500 to-teal-600',
      price: 'Starting ₹4,999',
    \},
    \{
      icon: Layers,
      title: 'Motion Graphics',
      subtitle: 'Animated Content',
      description: 'Dynamic animations that add life to your content and brand.',
      features: [
        'Animated intros/outros',
        'Lower thirds',
        'Logo animations',
        'Kinetic typography',
        'Explainer animations',
        'Social media animations',
      ],
      gradient: 'from-red-500 to-pink-600',
      price: 'Starting ₹799',
    \},
  ];

  return (
<div classname="min-h-screen pt-20">
  \{/* Hero */\}
  <section classname="py-16 md:py-24 px-4 relative overflow-hidden">
    <div classname="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl">
      <div classname="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl">
        <div classname="max-w-7xl mx-auto relative">
          <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" animate="{{" 1,="" 0="" classname="text-center max-w-3xl mx-auto">
            <motion.div initial="{{" opacity:="" 0,="" scale:="" 0.9="" }}="" animate="{{" 1,="" 1="" transition="{{" delay:="" 0.1="" classname="inline-flex items-center gap-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full mb-6">
              <sparkles classname="w-4 h-4 text-purple-400">
                <span classname="text-sm text-purple-300">
                  Everything You Need
                </span>
              </sparkles>
            </motion.div>
            <h1 classname="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              <span classname="text-white">
                Our
              </span>
              <span classname="bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Services
              </span>
            </h1>
            <p classname="text-xl text-gray-400">
              From quick edits to complete brand makeovers – we've got everything 
              to make your content stand out in the feed.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  </section>
  \{/* Services Grid */\}
  <section classname="py-12 px-4">
    <div classname="max-w-7xl mx-auto">
      <div classname="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        \{services.map((service, index) => (
        <motion.div key="{index}" initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.1="" whilehover="{{" -5="" classname="group relative bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-2xl overflow-hidden hover:border-white/20 transition-all duration-500">
          \{/* Glow effect */\}
          <div classname="{`absolute" inset-0="" bg-gradient-to-r="" ${service.gradient}="" opacity-0="" group-hover:opacity-5="" transition-opacity="" duration-500`}="">
            <div classname="p-6 md:p-8">
              \{/* Icon */\}
              <div classname="{`w-14" h-14="" rounded-xl="" bg-gradient-to-r="" ${service.gradient}="" flex="" items-center="" justify-center="" mb-6="" group-hover:scale-110="" transition-transform="" duration-300`}="">
                <service.icon classname="w-7 h-7 text-white">
                </service.icon>
              </div>
              \{/* Title */\}
              <h3 classname="text-2xl font-bold text-white mb-1">
                \{service.title\}
              </h3>
              <p classname="text-sm text-gray-400 mb-4">
                \{service.subtitle\}
              </p>
              \{/* Description */\}
              <p classname="text-gray-300 mb-6">
                \{service.description\}
              </p>
              \{/* Features */\}
              <ul classname="space-y-2 mb-6">
                \{service.features.map((feature, i) => (
                <li key="{i}" classname="flex items-center gap-2 text-sm text-gray-400">
                  <check classname="w-4 h-4 text-cyan-400 flex-shrink-0">
                    \{feature\}
                  </check>
                </li>
                ))\}
              </ul>
              \{/* Price & CTA */\}
              <div classname="flex items-center justify-between pt-4 border-t border-white/10">
                <span classname="{`text-lg" font-bold="" bg-gradient-to-r="" ${service.gradient}="" bg-clip-text="" text-transparent`}="">
                  \{service.price\}
                </span>
                <link to="/contact" />
                <button classname="flex items-center gap-1 text-sm text-gray-400 hover:text-white transition-colors group/btn">
                  Get Quote
                  <arrowright classname="w-4 h-4 group-hover/btn:translate-x-1 transition-transform">
                  </arrowright>
                </button>
              </div>
            </div>
            ))\}
          </div>
        </motion.div>
      </div>
    </div>
  </section>
  \{/* Process Section */\}
  <section classname="py-20 px-4">
    <div classname="max-w-7xl mx-auto">
      <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-16">
        <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
          How It\{' '\}
          <span classname="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
            Works
          </span>
        </h2>
      </motion.div>
      <div classname="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        \{[
              \{ step: '01', title: 'Send Brief', desc: 'DM us or fill the form with your requirements' \},
              \{ step: '02', title: 'Get Quote', desc: 'Receive a custom quote within 2 hours' \},
              \{ step: '03', title: 'We Create', desc: 'Our team works magic on your project' \},
              \{ step: '04', title: 'You Shine', desc: 'Get your files & watch your content go viral' \},
            ].map((item, index) => (
        <motion.div key="{index}" initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.1="" classname="relative text-center p-6">
          <div classname="text-6xl font-bold text-white/5 absolute top-0 left-1/2 -translate-x-1/2">
            \{item.step\}
          </div>
          <div classname="relative pt-8">
            <div classname="w-12 h-12 mx-auto mb-4 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 flex items-center justify-center text-white font-bold">
              \{item.step\}
            </div>
            <h3 classname="text-xl font-bold text-white mb-2">
              \{item.title\}
            </h3>
            <p classname="text-gray-400 text-sm">
              \{item.desc\}
            </p>
          </div>
          \{index < 3 && (
          <div classname="hidden lg:block absolute top-1/2 right-0 translate-x-1/2 w-8 h-0.5 bg-gradient-to-r from-cyan-500/50 to-purple-500/50">
            )\}
              
            ))\}
          </div>
        </motion.div>
      </div>
    </div>
  </section>
  \{/* CTA */\}
  <section classname="py-20 px-4">
    <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="max-w-4xl mx-auto text-center p-8 md:p-12 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10 border border-white/10 rounded-3xl">
      <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
        Ready to Start Your Project?
      </h2>
      <p classname="text-gray-400 text-lg mb-8">
        Let's discuss your requirements and create something amazing together.
      </p>
      <div classname="flex flex-col sm:flex-row gap-4 justify-center">
        <link to="/contact" />
        <glowbutton size="lg">
          Get a Free Quote
          <arrowright classname="w-5 h-5">
          </arrowright>
        </glowbutton>
        <link to="/pricing" />
        <glowbutton variant="outline" size="lg">
          View Pricing
        </glowbutton>
      </div>
    </motion.div>
  </section>
</div>
);
\}
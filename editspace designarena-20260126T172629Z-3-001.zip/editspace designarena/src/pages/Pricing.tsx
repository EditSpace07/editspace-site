import \{ useState \} from 'react';
import \{ motion \} from 'framer-motion';
import \{ Link \} from 'react-router-dom';
import \{ Check, X, Sparkles, Zap, Crown, ArrowRight \} from 'lucide-react';
import GlowButton from '../components/GlowButton';

export default function Pricing() \{
  const [billingCycle, setBillingCycle] = useState<'single' | 'monthly'>('single');

  const plans = [
    \{
      name: 'Starter',
      icon: Zap,
      description: 'Perfect for trying out our services',
      price: \{ single: 499, monthly: 1999 \},
      color: 'from-cyan-400 to-blue-500',
      features: [
        \{ text: '1 Reel/Short edit', included: true \},
        \{ text: 'Basic transitions', included: true \},
        \{ text: 'Music sync', included: true \},
        \{ text: '48hr delivery', included: true \},
        \{ text: '1 revision', included: true \},
        \{ text: 'Color grading', included: false \},
        \{ text: 'Custom effects', included: false \},
        \{ text: 'Priority support', included: false \},
      ],
      popular: false,
    \},
    \{
      name: 'Creator',
      icon: Sparkles,
      description: 'Most popular for growing creators',
      price: \{ single: 1499, monthly: 4999 \},
      color: 'from-purple-400 to-pink-500',
      features: [
        \{ text: '3 Reels/Shorts edits', included: true \},
        \{ text: 'Trending transitions', included: true \},
        \{ text: 'Music sync + SFX', included: true \},
        \{ text: '24hr delivery', included: true \},
        \{ text: '3 revisions', included: true \},
        \{ text: 'Color grading', included: true \},
        \{ text: 'Custom effects', included: true \},
        \{ text: 'Priority support', included: false \},
      ],
      popular: true,
    \},
    \{
      name: 'Pro',
      icon: Crown,
      description: 'For serious content creators',
      price: \{ single: 3999, monthly: 9999 \},
      color: 'from-yellow-400 to-orange-500',
      features: [
        \{ text: '10 Reels/Shorts edits', included: true \},
        \{ text: 'Premium transitions', included: true \},
        \{ text: 'Full audio design', included: true \},
        \{ text: 'Same-day delivery', included: true \},
        \{ text: 'Unlimited revisions', included: true \},
        \{ text: 'Advanced color grading', included: true \},
        \{ text: 'Custom motion graphics', included: true \},
        \{ text: '24/7 Priority support', included: true \},
      ],
      popular: false,
    \},
  ];

  const addOns = [
    \{ name: 'Thumbnail Design', price: 199, per: 'per thumbnail' \},
    \{ name: 'Captions/Subtitles', price: 99, per: 'per video' \},
    \{ name: 'Logo Animation', price: 999, per: 'one-time' \},
    \{ name: 'Rush Delivery', price: 299, per: 'per project' \},
    \{ name: 'Extra Revision', price: 149, per: 'per revision' \},
    \{ name: 'Raw Files', price: 199, per: 'per project' \},
  ];

  return (
<div classname="min-h-screen pt-20">
  \{/* Hero */\}
  <section classname="py-16 md:py-24 px-4 relative overflow-hidden">
    <div classname="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl">
      <div classname="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl">
        <div classname="max-w-7xl mx-auto relative">
          <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" animate="{{" 1,="" 0="" classname="text-center max-w-3xl mx-auto">
            <motion.div initial="{{" opacity:="" 0,="" scale:="" 0.9="" }}="" animate="{{" 1,="" 1="" transition="{{" delay:="" 0.1="" classname="inline-flex items-center gap-2 px-4 py-2 bg-pink-500/10 border border-pink-500/20 rounded-full mb-6">
              <sparkles classname="w-4 h-4 text-pink-400">
                <span classname="text-sm text-pink-300">
                  Affordable Pricing
                </span>
              </sparkles>
            </motion.div>
            <h1 classname="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              <span classname="text-white">
                Simple
              </span>
              <span classname="bg-gradient-to-r from-pink-400 via-purple-500 to-cyan-400 bg-clip-text text-transparent">
                Pricing
              </span>
            </h1>
            <p classname="text-xl text-gray-400 mb-8">
              No hidden fees. No surprises. Just great content at prices that make sense for creators.
            </p>
            \{/* Billing Toggle */\}
            <div classname="inline-flex items-center gap-4 p-1.5 bg-white/5 border border-white/10 rounded-full">
              <button onClick="{()" =="">
                setBillingCycle('single')\}
                className=\{`px-6 py-2.5 rounded-full text-sm font-medium transition-all $\{
                  billingCycle === 'single'
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white'
                    : 'text-gray-400 hover:text-white'
                \}`\}
              >
                One-Time
              </button>
              <button onClick="{()" =="">
                setBillingCycle('monthly')\}
                className=\{`px-6 py-2.5 rounded-full text-sm font-medium transition-all relative $\{
                  billingCycle === 'monthly'
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white'
                    : 'text-gray-400 hover:text-white'
                \}`\}
              >
                Monthly
                <span classname="absolute -top-2 -right-2 px-2 py-0.5 bg-green-500 text-white text-xs rounded-full">
                  Save 30%
                </span>
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  </section>
  \{/* Pricing Cards */\}
  <section classname="py-12 px-4">
    <div classname="max-w-7xl mx-auto">
      <div classname="grid md:grid-cols-3 gap-6 lg:gap-8">
        \{plans.map((plan, index) => (
        <motion.div key="{index}" initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.1="" classname="{`relative" bg-gradient-to-b="" from-white="" 5="" to-transparent="" border="" rounded-2xl="" overflow-hidden="" ${="" plan.popular="" ?="" 'border-purple-500="" 50'="" :="" 'border-white="" 10'="" }`}="">
          \{/* Popular Badge */\}
                \{plan.popular && (
          <div classname="absolute top-0 left-0 right-0 bg-gradient-to-r from-purple-500 to-pink-500 py-2 text-center">
            <span classname="text-white text-sm font-semibold">
              Most Popular
            </span>
          </div>
          )\}
          <div classname="{`p-6" md:p-8="" ${plan.popular="" ?="" 'pt-14'="" :="" ''}`}="">
            \{/* Icon & Name */\}
            <div classname="flex items-center gap-3 mb-4">
              <div classname="{`w-12" h-12="" rounded-xl="" bg-gradient-to-r="" ${plan.color}="" flex="" items-center="" justify-center`}="">
                <plan.icon classname="w-6 h-6 text-white">
                </plan.icon>
              </div>
              <div>
                <h3 classname="text-xl font-bold text-white">
                  \{plan.name\}
                </h3>
                <p classname="text-sm text-gray-400">
                  \{plan.description\}
                </p>
              </div>
            </div>
            \{/* Price */\}
            <div classname="mb-6">
              <div classname="flex items-baseline gap-1">
                <span classname="text-4xl font-bold text-white">
                  ₹\{plan.price[billingCycle].toLocaleString()\}
                </span>
                <span classname="text-gray-400">
                  /\{billingCycle === 'monthly' ? 'month' : 'project'\}
                </span>
              </div>
            </div>
            \{/* Features */\}
            <ul classname="space-y-3 mb-8">
              \{plan.features.map((feature, i) => (
              <li key="{i}" classname="flex items-center gap-3">
                \{feature.included ? (
                <check classname="w-5 h-5 text-green-400 flex-shrink-0">
                  ) : (
                  <x classname="w-5 h-5 text-gray-600 flex-shrink-0">
                    )\}
                    <span classname="{feature.included" ?="" 'text-gray-300'="" :="" 'text-gray-500'}="">
                      \{feature.text\}
                    </span>
                  </x>
                </check>
              </li>
              ))\}
            </ul>
            \{/* CTA */\}
            <link to="/contact" />
            <glowbutton variant="{plan.popular" ?="" 'primary'="" :="" 'outline'}="" classname="w-full">
              Get Started
            </glowbutton>
          </div>
        </motion.div>
        ))\}
      </div>
    </div>
  </section>
  \{/* Add-ons */\}
  <section classname="py-20 px-4">
    <div classname="max-w-7xl mx-auto">
      <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-12">
        <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
          Add-On\{' '\}
          <span classname="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
            Services
          </span>
        </h2>
        <p classname="text-gray-400">
          Enhance your package with these extras
        </p>
      </motion.div>
      <div classname="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        \{addOns.map((addon, index) => (
        <motion.div key="{index}" initial="{{" opacity:="" 0,="" scale:="" 0.95="" }}="" whileinview="{{" 1,="" 1="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.05="" whilehover="{{" 1.02="" classname="p-4 bg-white/5 border border-white/10 rounded-xl hover:border-cyan-500/30 transition-all flex items-center justify-between">
          <div>
            <h4 classname="text-white font-medium">
              \{addon.name\}
            </h4>
            <p classname="text-gray-500 text-sm">
              \{addon.per\}
            </p>
          </div>
          <span classname="text-lg font-bold text-cyan-400">
            ₹\{addon.price\}
          </span>
        </motion.div>
        ))\}
      </div>
    </div>
  </section>
  \{/* FAQ */\}
  <section classname="py-20 px-4">
    <div classname="max-w-3xl mx-auto">
      <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-12">
        <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
          Frequently Asked\{' '\}
          <span classname="bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent">
            Questions
          </span>
        </h2>
      </motion.div>
      <div classname="space-y-4">
        \{[
              \{
                q: 'What payment methods do you accept?',
                a: 'We accept UPI, bank transfer, PayPal, and all major cards. 50% advance for new clients.',
              \},
              \{
                q: 'How do revisions work?',
                a: 'Each plan includes a set number of revisions. Additional revisions can be purchased as add-ons.',
              \},
              \{
                q: 'What format will I receive my files in?',
                a: 'Videos are delivered in MP4 (1080p/4K). Graphics in PNG/JPG/PDF. Raw files available as add-on.',
              \},
              \{
                q: 'Do you offer refunds?',
                a: 'Yes, we offer full refunds before work begins. Partial refunds based on work completed.',
              \},
              \{
                q: 'Can I upgrade my plan mid-project?',
                a: 'Absolutely! You can upgrade anytime and only pay the difference.',
              \},
            ].map((faq, index) => (
        <motion.div key="{index}" initial="{{" opacity:="" 0,="" y:="" 20="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.1="" classname="p-6 bg-white/5 border border-white/10 rounded-xl">
          <h4 classname="text-white font-semibold mb-2">
            \{faq.q\}
          </h4>
          <p classname="text-gray-400">
            \{faq.a\}
          </p>
        </motion.div>
        ))\}
      </div>
    </div>
  </section>
  \{/* CTA */\}
  <section classname="py-20 px-4">
    <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="max-w-4xl mx-auto text-center p-8 md:p-12 bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-orange-500/10 border border-white/10 rounded-3xl">
      <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
        Need a Custom Quote?
      </h2>
      <p classname="text-gray-400 text-lg mb-8">
        Have a unique project? Let's discuss your requirements and create a custom package.
      </p>
      <link to="/contact" />
      <glowbutton size="lg">
        Get Custom Quote
        <arrowright classname="w-5 h-5">
        </arrowright>
      </glowbutton>
    </motion.div>
  </section>
</div>
);
\}
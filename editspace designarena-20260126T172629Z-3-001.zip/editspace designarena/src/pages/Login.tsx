import \{ useState, useEffect, useRef \} from 'react';
import \{ motion \} from 'framer-motion';
import \{ Link \} from 'react-router-dom';
import \{ Mail, Lock, Eye, EyeOff, User, ArrowRight \} from 'lucide-react';
import GlowButton from '../components/GlowButton';

export default function Login() \{
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const canvasRef = useRef
<htmlcanvaselement>
  (null);

  // 3D Animated Background
  useEffect(() => \{
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let cubes: Cube[] = [];

    const resize = () => \{
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    \};

    class Cube \{
      x: number;
      y: number;
      z: number;
      size: number;
      rotationX: number;
      rotationY: number;
      speedX: number;
      speedY: number;
      color: string;

      constructor() \{
        this.x = Math.random() * canvas!.width;
        this.y = Math.random() * canvas!.height;
        this.z = Math.random() * 500 + 100;
        this.size = Math.random() * 40 + 20;
        this.rotationX = Math.random() * Math.PI * 2;
        this.rotationY = Math.random() * Math.PI * 2;
        this.speedX = (Math.random() - 0.5) * 0.02;
        this.speedY = (Math.random() - 0.5) * 0.02;
        const colors = ['#06b6d4', '#8b5cf6', '#ec4899', '#f59e0b'];
        this.color = colors[Math.floor(Math.random() * colors.length)];
      \}

      update() \{
        this.rotationX += this.speedX;
        this.rotationY += this.speedY;
        this.y += 0.2;
        if (this.y > canvas!.height + 100) \{
          this.y = -100;
          this.x = Math.random() * canvas!.width;
        \}
      \}

      draw() \{
        if (!ctx) return;
        const scale = 500 / (500 + this.z);
        const projectedSize = this.size * scale;
        
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotationX);
        
        // Draw cube faces with gradient
        ctx.globalAlpha = 0.1 + (scale * 0.2);
        ctx.strokeStyle = this.color;
        ctx.lineWidth = 1;
        
        // Front face
        ctx.beginPath();
        ctx.rect(-projectedSize/2, -projectedSize/2, projectedSize, projectedSize);
        ctx.stroke();
        
        // Back face (offset)
        const offset = projectedSize * 0.3;
        ctx.beginPath();
        ctx.rect(-projectedSize/2 + offset, -projectedSize/2 - offset, projectedSize, projectedSize);
        ctx.stroke();
        
        // Connect corners
        ctx.beginPath();
        ctx.moveTo(-projectedSize/2, -projectedSize/2);
        ctx.lineTo(-projectedSize/2 + offset, -projectedSize/2 - offset);
        ctx.moveTo(projectedSize/2, -projectedSize/2);
        ctx.lineTo(projectedSize/2 + offset, -projectedSize/2 - offset);
        ctx.moveTo(projectedSize/2, projectedSize/2);
        ctx.lineTo(projectedSize/2 + offset, projectedSize/2 - offset);
        ctx.moveTo(-projectedSize/2, projectedSize/2);
        ctx.lineTo(-projectedSize/2 + offset, projectedSize/2 - offset);
        ctx.stroke();
        
        ctx.restore();
      \}
    \}

    const init = () => \{
      cubes = [];
      for (let i = 0; i < 15; i++) \{
        cubes.push(new Cube());
      \}
    \};

    const animate = () => \{
      if (!ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      cubes.forEach(cube => \{
        cube.update();
        cube.draw();
      \});

      animationId = requestAnimationFrame(animate);
    \};

    resize();
    init();
    animate();

    window.addEventListener('resize', () => \{
      resize();
      init();
    \});

    return () => \{
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    \};
  \}, []);

  const handleSubmit = (e: React.FormEvent) => \{
    e.preventDefault();
    // Handle form submission
    alert(isLogin ? 'Login functionality coming soon!' : 'Sign up functionality coming soon!');
  \};

  return (
  <div classname="min-h-screen flex items-center justify-center px-4 py-20 relative overflow-hidden">
    \{/* 3D Animated Background */\}
    <canvas ref="{canvasRef}" classname="absolute inset-0 -z-10">
      <div classname="absolute inset-0 bg-black/70 -z-10">
        \{/* Gradient Orbs */\}
        <div classname="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/30 rounded-full blur-3xl animate-pulse">
          <div classname="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/30 rounded-full blur-3xl animate-pulse delay-1000">
            <motion.div initial="{{" opacity:="" 0,="" y:="" 30,="" rotatex:="" -10="" }}="" animate="{{" 1,="" 0="" transition="{{" duration:="" 0.8="" classname="w-full max-w-md relative" perspective:="" '1000px'="">
              \{/* Card */\}
              <motion.div initial="{{" rotatey:="" 0="" }}="" animate="{{" islogin="" ?="" :="" transition="{{" duration:="" 0.6="" classname="relative bg-black/50 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-10" transformstyle:="" 'preserve-3d'="">
                \{/* Glow effect */\}
                <div classname="absolute -inset-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 rounded-3xl blur opacity-20">
                  <div classname="relative">
                    \{/* Logo */\}
                    <div classname="text-center mb-8">
                      <link to="/" classname="inline-flex items-center gap-2 mb-4" />
                      <img src="/images/logo.png" alt="EditSpace" classname="w-12 h-12 rounded-lg" />
                      <span classname="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
                        EditSpace
                      </span>
                      <h1 classname="text-2xl font-bold text-white">
                        \{isLogin ? 'Welcome Back!' : 'Join EditSpace'\}
                      </h1>
                      <p classname="text-gray-400 mt-2">
                        \{isLogin ? 'Sign in to access your projects' : 'Create an account to get started'\}
                      </p>
                    </div>
                    \{/* Toggle */\}
                    <div classname="flex p-1 bg-white/5 rounded-full mb-8">
                      <button onClick="{()" =="">
                        setIsLogin(true)\}
                className=\{`flex-1 py-2.5 rounded-full text-sm font-medium transition-all $\{
                  isLogin
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white'
                    : 'text-gray-400 hover:text-white'
                \}`\}
              >
                Sign In
                      </button>
                      <button onClick="{()" =="">
                        setIsLogin(false)\}
                className=\{`flex-1 py-2.5 rounded-full text-sm font-medium transition-all $\{
                  !isLogin
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white'
                    : 'text-gray-400 hover:text-white'
                \}`\}
              >
                Sign Up
                      </button>
                    </div>
                    \{/* Form */\}
                    <form onSubmit="{handleSubmit}" classname="space-y-5">
                      \{/* Name field (signup only) */\}
              \{!isLogin && (
                      <motion.div initial="{{" opacity:="" 0,="" height:="" 0="" }}="" animate="{{" 1,="" 'auto'="" exit="{{">
                        <label classname="block text-sm text-gray-400 mb-2">
                          Full Name
                        </label>
                        <div classname="relative">
                          <user classname="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500">
                            <input type="text" value="{name}" onChange="{(e)" =="" />
                            setName(e.target.value)\}
                      placeholder="Your name"
                      className="w-full pl-12 pr-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                    />
                          </user>
                        </div>
                      </motion.div>
                      )\}

              \{/* Email */\}
                      <div>
                        <label classname="block text-sm text-gray-400 mb-2">
                          Email Address
                        </label>
                        <div classname="relative">
                          <mail classname="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500">
                            <input type="email" value="{email}" onChange="{(e)" =="" />
                            setEmail(e.target.value)\}
                    placeholder="you@example.com"
                    className="w-full pl-12 pr-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                  />
                          </mail>
                        </div>
                      </div>
                      \{/* Password */\}
                      <div>
                        <label classname="block text-sm text-gray-400 mb-2">
                          Password
                        </label>
                        <div classname="relative">
                          <lock classname="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500">
                            <input type="{showPassword" ?="" 'text'="" :="" 'password'}="" value="{password}" onChange="{(e)" =="" />
                            setPassword(e.target.value)\}
                    placeholder="••••••••"
                    className="w-full pl-12 pr-12 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all"
                  />
                            <button type="button" onClick="{()" =="">
                              setShowPassword(!showPassword)\}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300 transition-colors"
                  >
                    \{showPassword ?
                              <eyeoff classname="w-5 h-5">
                                :
                                <eye classname="w-5 h-5">
                                  \}
                                </eye>
                              </eyeoff>
                            </button>
                          </lock>
                        </div>
                      </div>
                      \{/* Forgot Password */\}
              \{isLogin && (
                      <div classname="text-right">
                        <button type="button" classname="text-sm text-cyan-400 hover:text-cyan-300 transition-colors">
                          Forgot password?
                        </button>
                      </div>
                      )\}

              \{/* Submit */\}
                      <glowbutton type="submit" classname="w-full" size="lg">
                        \{isLogin ? 'Sign In' : 'Create Account'\}
                        <arrowright classname="w-5 h-5">
                        </arrowright>
                      </glowbutton>
                    </form>
                    \{/* Divider */\}
                    <div classname="flex items-center gap-4 my-8">
                      <div classname="flex-1 h-px bg-white/10">
                        <span classname="text-gray-500 text-sm">
                          or continue with
                        </span>
                        <div classname="flex-1 h-px bg-white/10">
                        </div>
                        \{/* Social Login */\}
                        <div classname="grid grid-cols-2 gap-4">
                          <button classname="flex items-center justify-center gap-2 py-3 bg-white/5 border border-white/10 rounded-xl text-white hover:bg-white/10 transition-all">
                            <svg classname="w-5 h-5" viewbox="0 0 24 24">
                              <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                              <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                              <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                              <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                            </svg>
                            Google
                          </button>
                          <button classname="flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-pink-500/20 to-purple-500/20 border border-pink-500/20 rounded-xl text-white hover:from-pink-500/30 hover:to-purple-500/30 transition-all">
                            <svg classname="w-5 h-5" viewbox="0 0 24 24" fill="currentColor">
                              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                            </svg>
                            Instagram
                          </button>
                        </div>
                        \{/* Terms */\}
            \{!isLogin && (
                        <p classname="text-center text-gray-500 text-sm mt-6">
                          By signing up, you agree to our\{' '\}
                          <a href="#" classname="text-cyan-400 hover:underline">
                            Terms
                          </a>
                          \{' '\}
                and\{' '\}
                          <a href="#" classname="text-cyan-400 hover:underline">
                            Privacy Policy
                          </a>
                        </p>
                        )\}
                      </div>
                      \{/* Floating elements */\}
                      <motion.div animate="{{" y:="" [0,="" -10,="" 0],="" rotate:="" 5,="" 0]="" }}="" transition="{{" repeat:="" infinity,="" duration:="" 4="" classname="absolute -top-8 -right-8 w-16 h-16 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-xl opacity-20 blur-sm">
                        <motion.div animate="{{" y:="" [0,="" 10,="" 0],="" rotate:="" -5,="" 0]="" }}="" transition="{{" repeat:="" infinity,="" duration:="" 5,="" delay:="" 1="" classname="absolute -bottom-8 -left-8 w-20 h-20 bg-gradient-to-r from-pink-500 to-orange-500 rounded-full opacity-20 blur-sm">
                        </motion.div>
                      </motion.div>
                    </div>
                    );
\}
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </canvas>
  </div>
</htmlcanvaselement>
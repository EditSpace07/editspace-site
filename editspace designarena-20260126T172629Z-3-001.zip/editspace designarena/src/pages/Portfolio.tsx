import \{ useState, useRef \} from 'react';
import \{ motion, AnimatePresence \} from 'framer-motion';
import \{ Link \} from 'react-router-dom';
import \{ Play, X, Upload, ArrowRight, Sparkles, Filter \} from 'lucide-react';
import GlowButton from '../components/GlowButton';

export default function Portfolio() \{
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedItem, setSelectedItem] = useState
<number |="" null="">
  (null);
  const [uploadedFiles, setUploadedFiles] = useState
  <file[]>
    ([]);
  const fileInputRef = useRef
    <htmlinputelement>
      (null);

  const categories = [
    \{ id: 'all', label: 'All Work' \},
    \{ id: 'reels', label: 'Reels & Shorts' \},
    \{ id: 'graphics', label: 'Graphics' \},
    \{ id: 'websites', label: 'Websites' \},
    \{ id: 'branding', label: 'Branding' \},
  ];

  const portfolioItems = [
    \{
      id: 1,
      title: 'Cinematic Travel Reel',
      category: 'reels',
      image: '/images/portfolio-1.jpg',
      video: '/videos/reel-demo-1.mp4',
      client: '@wanderlust.india',
      type: 'video',
    \},
    \{
      id: 2,
      title: 'Abstract Brand Identity',
      category: 'branding',
      image: '/images/portfolio-2.jpg',
      client: 'TechStartup Co.',
      type: 'image',
    \},
    \{
      id: 3,
      title: 'Modern Portfolio Website',
      category: 'websites',
      image: '/images/portfolio-3.jpg',
      client: 'Creative Agency',
      type: 'image',
    \},
    \{
      id: 4,
      title: 'Lifestyle Content Edit',
      category: 'reels',
      image: '/images/portfolio-4.jpg',
      video: '/videos/reel-demo-2.mp4',
      client: '@lifestyle.creator',
      type: 'video',
    \},
    \{
      id: 5,
      title: 'Neon Social Graphics',
      category: 'graphics',
      image: '/images/portfolio-2.jpg',
      client: 'Music Artist',
      type: 'image',
    \},
    \{
      id: 6,
      title: 'E-commerce Website',
      category: 'websites',
      image: '/images/portfolio-3.jpg',
      client: 'Fashion Brand',
      type: 'image',
    \},
  ];

  const filteredItems = selectedCategory === 'all'
    ? portfolioItems
    : portfolioItems.filter(item => item.category === selectedCategory);

  const handleFileUpload = (e: React.ChangeEvent
      <htmlinputelement>
        ) => \{
    if (e.target.files) \{
      setUploadedFiles(Array.from(e.target.files));
    \}
  \};

  return (
        <div classname="min-h-screen pt-20">
          \{/* Hero */\}
          <section classname="py-16 md:py-24 px-4 relative overflow-hidden">
            <div classname="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl">
              <div classname="absolute bottom-0 left-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl">
                <div classname="max-w-7xl mx-auto relative">
                  <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" animate="{{" 1,="" 0="" classname="text-center max-w-3xl mx-auto">
                    <motion.div initial="{{" opacity:="" 0,="" scale:="" 0.9="" }}="" animate="{{" 1,="" 1="" transition="{{" delay:="" 0.1="" classname="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/20 rounded-full mb-6">
                      <sparkles classname="w-4 h-4 text-cyan-400">
                        <span classname="text-sm text-cyan-300">
                          Our Creative Work
                        </span>
                      </sparkles>
                    </motion.div>
                    <h1 classname="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
                      <span classname="text-white">
                        Our
                      </span>
                      <span classname="bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                        Portfolio
                      </span>
                    </h1>
                    <p classname="text-xl text-gray-400">
                      Check out some of our recent work. From viral reels to stunning websites – 
              we bring creative visions to life.
                    </p>
                  </motion.div>
                </div>
              </div>
            </div>
          </section>
          \{/* Filter */\}
          <section classname="py-8 px-4">
            <div classname="max-w-7xl mx-auto">
              <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" 1,="" 0="" classname="flex flex-wrap items-center justify-center gap-2">
                <filter classname="w-5 h-5 text-gray-400 mr-2">
                  \{categories.map((category) => (
                  <button key="{category.id}" onClick="{()" =="">
                    setSelectedCategory(category.id)\}
                className=\{`px-4 py-2 rounded-full text-sm font-medium transition-all $\{
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white'
                    : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white border border-white/10'
                \}`\}
              >
                \{category.label\}
                  </button>
                  ))\}
                </filter>
              </motion.div>
            </div>
          </section>
          \{/* Portfolio Grid */\}
          <section classname="py-12 px-4">
            <div classname="max-w-7xl mx-auto">
              <motion.div layout="" classname="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <animatepresence mode="popLayout">
                  \{filteredItems.map((item, index) => (
                  <motion.div key="{item.id}" layout="" initial="{{" opacity:="" 0,="" scale:="" 0.9="" }}="" animate="{{" 1,="" 1="" exit="{{" transition="{{" delay:="" index="" *="" 0.05="" whilehover="{{" y:="" -10="" classname="group relative aspect-[4/3] rounded-2xl overflow-hidden cursor-pointer" onClick="{()" =="">
                    setSelectedItem(item.id)\}
                >
                    <img src="{item.image}" alt="{item.title}" classname="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                    \{/* Overlay */\}
                    <div classname="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      \{/* Play button for videos */\}
                  \{item.type === 'video' && (
                      <div classname="absolute inset-0 flex items-center justify-center">
                        <div classname="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:scale-110">
                          <play classname="w-8 h-8 text-white ml-1" fill="white">
                          </play>
                        </div>
                      </div>
                      )\}
                  
                  \{/* Info */\}
                      <div classname="absolute bottom-0 left-0 right-0 p-6 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                        <h3 classname="text-xl font-bold text-white mb-1">
                          \{item.title\}
                        </h3>
                        <p classname="text-cyan-400 text-sm">
                          \{item.client\}
                        </p>
                      </div>
                      \{/* Glow border on hover */\}
                      <div classname="absolute inset-0 border-2 border-transparent group-hover:border-cyan-500/50 rounded-2xl transition-colors duration-300">
                        ))\}
                      </div>
                    </div>
                  </motion.div>
                </animatepresence>
              </motion.div>
            </div>
          </section>
          \{/* Upload Section */\}
          <section classname="py-20 px-4">
            <div classname="max-w-4xl mx-auto">
              <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-12">
                <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
                  Upload Your\{' '\}
                  <span classname="bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent">
                    Project
                  </span>
                </h2>
                <p classname="text-gray-400">
                  Have a project in mind? Upload your files and get a quick quote.
                </p>
              </motion.div>
              <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="p-8 md:p-12 bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-3xl">
                <input type="file" ref="{fileInputRef}" onChange="{handleFileUpload}" multiple={true} accept="video/*,image/*" classname="hidden" />
                <div onClick="{()" =="">
                  fileInputRef.current?.click()\}
              className="border-2 border-dashed border-white/20 hover:border-cyan-500/50 rounded-2xl p-12 text-center cursor-pointer transition-colors group"
            >
                  <div classname="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-cyan-500/20 to-purple-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <upload classname="w-10 h-10 text-cyan-400">
                    </upload>
                  </div>
                  <h3 classname="text-xl font-semibold text-white mb-2">
                    Drag & drop your files here
                  </h3>
                  <p classname="text-gray-400 mb-4">
                    or click to browse (Videos, Images up to 500MB)
                  </p>
                  <glowbutton variant="outline" size="sm">
                    Browse Files
                  </glowbutton>
                </div>
                \{/* Uploaded Files Preview */\}
            \{uploadedFiles.length > 0 && (
                <div classname="mt-8">
                  <h4 classname="text-white font-semibold mb-4">
                    Uploaded Files:
                  </h4>
                  <div classname="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    \{uploadedFiles.map((file, index) => (
                    <div key="{index}" classname="relative aspect-square rounded-lg overflow-hidden bg-white/5 border border-white/10">
                      \{file.type.startsWith('image/') ? (
                      <img src="{URL.createObjectURL(file)}" alt="{file.name}" classname="w-full h-full object-cover" />
                      ) : (
                      <div classname="w-full h-full flex items-center justify-center">
                        <play classname="w-8 h-8 text-cyan-400">
                        </play>
                      </div>
                      )\}
                      <div classname="absolute bottom-0 left-0 right-0 p-2 bg-black/80 text-xs text-gray-300 truncate">
                        \{file.name\}
                      </div>
                    </div>
                    ))\}
                  </div>
                  <div classname="mt-6 text-center">
                    <link to="/contact" />
                    <glowbutton>
                      Get Quote for These Files
                      <arrowright classname="w-5 h-5">
                      </arrowright>
                    </glowbutton>
                  </div>
                </div>
                )\}
              </motion.div>
            </div>
          </section>
          \{/* Lightbox Modal */\}
          <animatepresence>
            \{selectedItem && (
            <motion.div initial="{{" opacity:="" 0="" }}="" animate="{{" 1="" exit="{{" classname="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm" onClick="{()" =="">
              setSelectedItem(null)\}
          >
              <button classname="absolute top-6 right-6 p-2 text-white hover:text-cyan-400 transition-colors" onClick="{()" =="">
                setSelectedItem(null)\}
            >
                <x classname="w-8 h-8">
                </x>
              </button>
              <motion.div initial="{{" scale:="" 0.9,="" opacity:="" 0="" }}="" animate="{{" 1,="" 1="" exit="{{" classname="max-w-4xl w-full" onClick="{(e)" =="">
                e.stopPropagation()\}
            >
              \{(() => \{
                const item = portfolioItems.find(i => i.id === selectedItem);
                if (!item) return null;
                
                return item.type === 'video' && item.video ? (
                <video src="{item.video}" controls={true} autoPlay={true} classname="w-full rounded-2xl">
                  ) : (
                  <img src="{item.image}" alt="{item.title}" classname="w-full rounded-2xl" />
                  );
              \})()\}
                </video>
              </motion.div>
            </motion.div>
            )\}
          </animatepresence>
          \{/* CTA */\}
          <section classname="py-20 px-4">
            <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="max-w-4xl mx-auto text-center">
              <h2 classname="text-3xl sm:text-4xl font-bold text-white mb-4">
                Like What You See?
              </h2>
              <p classname="text-gray-400 text-lg mb-8">
                Let's create something amazing for your brand too!
              </p>
              <div classname="flex flex-col sm:flex-row gap-4 justify-center">
                <link to="/contact" />
                <glowbutton size="lg">
                  Start Your Project
                  <arrowright classname="w-5 h-5">
                  </arrowright>
                </glowbutton>
                <a href="https://instagram.com/editspace.in" target="_blank" rel="noopener noreferrer">
                  <glowbutton variant="outline" size="lg">
                    📱 DM on Instagram
                  </glowbutton>
                </a>
              </div>
            </motion.div>
          </section>
        </div>
        );
\}
      </htmlinputelement>
    </htmlinputelement>
  </file[]>
</number>
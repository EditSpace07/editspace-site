import \{ useState \} from 'react';
import \{ motion \} from 'framer-motion';
import \{ Send, Instagram, Mail, MapPin, Clock, MessageCircle, Sparkles, ExternalLink \} from 'lucide-react';
import GlowButton from '../components/GlowButton';

export default function Contact() \{
  const [formData, setFormData] = useState(\{
    name: '',
    email: '',
    service: '',
    budget: '',
    message: '',
  \});

  const handleSubmit = (e: React.FormEvent) => \{
    e.preventDefault();
    // Open Google Form in new tab
    window.open('https://forms.google.com/your-form-id', '_blank');
  \};

  const handleChange = (e: React.ChangeEvent
<htmlinputelement |="" htmltextareaelement="" htmlselectelement="">
  ) => \{
    setFormData(\{ ...formData, [e.target.name]: e.target.value \});
  \};

  return (
  <div classname="min-h-screen pt-20">
    \{/* Hero */\}
    <section classname="py-16 md:py-24 px-4 relative overflow-hidden">
      <div classname="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl">
        <div classname="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl">
          <div classname="max-w-7xl mx-auto relative">
            <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" animate="{{" 1,="" 0="" classname="text-center max-w-3xl mx-auto">
              <motion.div initial="{{" opacity:="" 0,="" scale:="" 0.9="" }}="" animate="{{" 1,="" 1="" transition="{{" delay:="" 0.1="" classname="inline-flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full mb-6">
                <messagecircle classname="w-4 h-4 text-green-400">
                  <span classname="text-sm text-green-300">
                    We Reply Within 2 Hours
                  </span>
                </messagecircle>
              </motion.div>
              <h1 classname="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
                <span classname="text-white">
                  Let's
                </span>
                <span classname="bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                  Connect
                </span>
              </h1>
              <p classname="text-xl text-gray-400">
                Ready to level up your content? Drop us a message and let's create something amazing!
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
    \{/* Contact Content */\}
    <section classname="py-12 px-4">
      <div classname="max-w-7xl mx-auto">
        <div classname="grid lg:grid-cols-2 gap-12">
          \{/* Contact Info */\}
          <motion.div initial="{{" opacity:="" 0,="" x:="" -30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="">
            <h2 classname="text-2xl font-bold text-white mb-6">
              Quick Contact
            </h2>
            <div classname="space-y-4 mb-8">
              \{/* Instagram DM - Primary */\}
              <a href="https://instagram.com/editspace.in" target="_blank" rel="noopener noreferrer" classname="group flex items-center gap-4 p-5 bg-gradient-to-r from-pink-500/10 to-purple-500/10 border border-pink-500/20 rounded-2xl hover:border-pink-500/40 transition-all">
                <div classname="w-14 h-14 rounded-xl bg-gradient-to-r from-pink-500 to-purple-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <instagram classname="w-7 h-7 text-white">
                  </instagram>
                </div>
                <div classname="flex-1">
                  <h3 classname="text-white font-semibold text-lg">
                    DM on Instagram
                  </h3>
                  <p classname="text-gray-400">
                    @editspace.in • Fastest response!
                  </p>
                </div>
                <externallink classname="w-5 h-5 text-gray-500 group-hover:text-pink-400 transition-colors">
                </externallink>
              </a>
              \{/* Email */\}
              <a href="mailto:hello@editspace.in" classname="group flex items-center gap-4 p-5 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-2xl hover:border-cyan-500/40 transition-all">
                <div classname="w-14 h-14 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <mail classname="w-7 h-7 text-white">
                  </mail>
                </div>
                <div classname="flex-1">
                  <h3 classname="text-white font-semibold text-lg">
                    Email Us
                  </h3>
                  <p classname="text-gray-400">
                    hello@editspace.in
                  </p>
                </div>
                <externallink classname="w-5 h-5 text-gray-500 group-hover:text-cyan-400 transition-colors">
                </externallink>
              </a>
              \{/* Location */\}
              <div classname="flex items-center gap-4 p-5 bg-white/5 border border-white/10 rounded-2xl">
                <div classname="w-14 h-14 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center">
                  <mappin classname="w-7 h-7 text-white">
                  </mappin>
                </div>
                <div>
                  <h3 classname="text-white font-semibold text-lg">
                    Based In
                  </h3>
                  <p classname="text-gray-400">
                    Kolkata, West Bengal, India
                  </p>
                </div>
              </div>
              \{/* Response Time */\}
              <div classname="flex items-center gap-4 p-5 bg-white/5 border border-white/10 rounded-2xl">
                <div classname="w-14 h-14 rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 flex items-center justify-center">
                  <clock classname="w-7 h-7 text-white">
                  </clock>
                </div>
                <div>
                  <h3 classname="text-white font-semibold text-lg">
                    Working Hours
                  </h3>
                  <p classname="text-gray-400">
                    Mon-Sat: 10AM - 10PM IST
                  </p>
                </div>
              </div>
            </div>
            \{/* Quick Quote CTA */\}
            <div classname="p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl">
              <div classname="flex items-center gap-2 mb-3">
                <sparkles classname="w-5 h-5 text-purple-400">
                  <h3 classname="text-white font-semibold">
                    Need a Quick Quote?
                  </h3>
                </sparkles>
              </div>
              <p classname="text-gray-400 text-sm mb-4">
                DM us on Instagram with your requirements and get a quote within 2 hours!
              </p>
              <a href="https://instagram.com/editspace.in" target="_blank" rel="noopener noreferrer">
                <glowbutton size="sm">
                  <instagram classname="w-4 h-4">
                    DM Now
                  </instagram>
                </glowbutton>
              </a>
            </div>
          </motion.div>
          \{/* Contact Form */\}
          <motion.div initial="{{" opacity:="" 0,="" x:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="">
            <div classname="p-6 md:p-8 bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-3xl">
              <h2 classname="text-2xl font-bold text-white mb-2">
                Send a Message
              </h2>
              <p classname="text-gray-400 mb-6">
                Fill out the form and we'll get back to you ASAP!
              </p>
              <form onSubmit="{handleSubmit}" classname="space-y-5">
                \{/* Name */\}
                <div>
                  <label classname="block text-sm text-gray-400 mb-2">
                    Your Name *
                  </label>
                  <input type="text" name="name" value="{formData.name}" onChange="{handleChange}" required={true} placeholder="John Doe" classname="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all" />
                </div>
                \{/* Email */\}
                <div>
                  <label classname="block text-sm text-gray-400 mb-2">
                    Email Address *
                  </label>
                  <input type="email" name="email" value="{formData.email}" onChange="{handleChange}" required={true} placeholder="you@example.com" classname="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all" />
                </div>
                \{/* Service */\}
                <div>
                  <label classname="block text-sm text-gray-400 mb-2">
                    Service Needed *
                  </label>
                  <select name="service" value="{formData.service}" onChange="{handleChange}" required={true} classname="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all appearance-none cursor-pointer">
                    <option value="" classname="bg-gray-900">
                      Select a service
                    </option>
                    <option value="reels" classname="bg-gray-900">
                      Reels/Shorts Editing
                    </option>
                    <option value="thumbnails" classname="bg-gray-900">
                      Thumbnail Design
                    </option>
                    <option value="graphics" classname="bg-gray-900">
                      Social Media Graphics
                    </option>
                    <option value="branding" classname="bg-gray-900">
                      Logo & Branding
                    </option>
                    <option value="website" classname="bg-gray-900">
                      Website Development
                    </option>
                    <option value="motion" classname="bg-gray-900">
                      Motion Graphics
                    </option>
                    <option value="other" classname="bg-gray-900">
                      Other
                    </option>
                  </select>
                </div>
                \{/* Budget */\}
                <div>
                  <label classname="block text-sm text-gray-400 mb-2">
                    Budget Range
                  </label>
                  <select name="budget" value="{formData.budget}" onChange="{handleChange}" classname="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all appearance-none cursor-pointer">
                    <option value="" classname="bg-gray-900">
                      Select budget
                    </option>
                    <option value="500-1000" classname="bg-gray-900">
                      ₹500 - ₹1,000
                    </option>
                    <option value="1000-2500" classname="bg-gray-900">
                      ₹1,000 - ₹2,500
                    </option>
                    <option value="2500-5000" classname="bg-gray-900">
                      ₹2,500 - ₹5,000
                    </option>
                    <option value="5000-10000" classname="bg-gray-900">
                      ₹5,000 - ₹10,000
                    </option>
                    <option value="10000+" classname="bg-gray-900">
                      ₹10,000+
                    </option>
                  </select>
                </div>
                \{/* Message */\}
                <div>
                  <label classname="block text-sm text-gray-400 mb-2">
                    Project Details *
                  </label>
                  <textarea name="message" value="{formData.message}" onChange="{handleChange}" required={true} rows="{4}" placeholder="Tell us about your project, timeline, and any specific requirements..." classname="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all resize-none">
                    </div>

                  \{/* Submit */\}
                  <GlowButton type="submit" className="w-full" size="lg">
                    <Send className="w-5 h-5" /> Send Message
                  </GlowButton>
                </form>

                \{/* Google Form Link */\}
                <div className="mt-6 pt-6 border-t border-white/10 text-center">
                  <p className="text-gray-400 text-sm mb-3">Prefer a detailed form?</p>
                  <a
                    href="https://forms.google.com/your-form-id"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors text-sm"
                  >
                    Fill out our Google Form <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      \{/* Map / Location Visual */\}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial=\{\{ opacity: 0, y: 30 \}\}
            whileInView=\{\{ opacity: 1, y: 0 \}\}
            viewport=\{\{ once: true \}\}
            className="relative h-[300px] md:h-[400px] rounded-3xl overflow-hidden"
          >
            \{/* Stylized map background */\}
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-purple-500/10 to-pink-500/10" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSA2MCAwIEwgMCAwIDAgNjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-50" />
            
            \{/* Location Pin */\}
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                initial=\{\{ scale: 0 \}\}
                whileInView=\{\{ scale: 1 \}\}
                viewport=\{\{ once: true \}\}
                transition=\{\{ type: 'spring', bounce: 0.5, delay: 0.3 \}\}
                className="text-center"
              >
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 flex items-center justify-center animate-pulse">
                  <MapPin className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Kolkata, India</h3>
                <p className="text-gray-400">Serving creators worldwide 🌍</p>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
\}
                  </textarea>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  </div>
</htmlinputelement>
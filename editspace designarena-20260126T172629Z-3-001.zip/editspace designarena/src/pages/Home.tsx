import \{ motion \} from 'framer-motion';
import \{ Link \} from 'react-router-dom';
import \{ ArrowRight, Play, Sparkles, Zap, Palette, Globe, Star, ChevronRight \} from 'lucide-react';
import GlowButton from '../components/GlowButton';
import ReelsPlayer from '../components/ReelsPlayer';

export default function Home() \{
  const features = [
    \{
      icon: Zap,
      title: 'Lightning Fast',
      description: '24-48 hour turnaround for most projects',
      color: 'from-yellow-400 to-orange-500',
    \},
    \{
      icon: Palette,
      title: 'Trendy Edits',
      description: 'Latest effects, transitions & styles',
      color: 'from-pink-400 to-purple-500',
    \},
    \{
      icon: Globe,
      title: 'Multi-Platform',
      description: 'Optimized for Reels, Shorts & TikTok',
      color: 'from-cyan-400 to-blue-500',
    \},
  ];

  const stats = [
    \{ value: '500+', label: 'Projects Delivered' \},
    \{ value: '100+', label: 'Happy Creators' \},
    \{ value: '4.9★', label: 'Client Rating' \},
    \{ value: '24hrs', label: 'Avg. Delivery' \},
  ];

  return (
<div classname="min-h-screen">
  \{/* Hero Section */\}
  <section classname="relative min-h-screen flex items-center justify-center px-4 pt-20 pb-12 overflow-hidden">
    \{/* Background Video */\}
    <div classname="absolute inset-0 -z-10">
      <video autoPlay={true} loop={true} muted={true} playsinline="" classname="w-full h-full object-cover opacity-30">
        <source src="/videos/hero-demo.mp4" type="video/mp4" />
      </video>
      <div classname="absolute inset-0 bg-gradient-to-b from-black via-black/80 to-black">
      </div>
      \{/* Animated Gradient Orbs */\}
      <div classname="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse">
        <div classname="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-1000">
          <div classname="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-pink-500/10 rounded-full blur-3xl">
            <div classname="max-w-7xl mx-auto w-full">
              <div classname="grid lg:grid-cols-2 gap-12 items-center">
                \{/* Left Content */\}
                <motion.div initial="{{" opacity:="" 0,="" x:="" -50="" }}="" animate="{{" 1,="" 0="" transition="{{" duration:="" 0.8="" classname="text-center lg:text-left">
                  <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" 1,="" 0="" transition="{{" delay:="" 0.2="" classname="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/20 rounded-full mb-6">
                    <sparkles classname="w-4 h-4 text-cyan-400">
                      <span classname="text-sm text-gray-300">
                        Kolkata's #1 Creative Studio
                      </span>
                    </sparkles>
                  </motion.div>
                  <motion.h1 initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" 1,="" 0="" transition="{{" delay:="" 0.3="" classname="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight mb-6">
                    <span classname="text-white">
                      Create
                    </span>
                    <span classname="bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                      Viral Content
                    </span>
                    <br />
                    <span classname="text-white">
                      That
                    </span>
                    <span classname="relative">
                      <span classname="bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent">
                        Converts
                      </span>
                      <motion.span initial="{{" width:="" 0="" }}="" animate="{{" '100%'="" transition="{{" delay:="" 1,="" duration:="" 0.8="" classname="absolute -bottom-2 left-0 h-1 bg-gradient-to-r from-pink-400 to-orange-400 rounded-full">
                      </motion.span>
                    </span>
                  </motion.h1>
                  <motion.p initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" 1,="" 0="" transition="{{" delay:="" 0.4="" classname="text-lg sm:text-xl text-gray-400 mb-8 max-w-xl mx-auto lg:mx-0">
                    Premium video editing, graphic design & web development for Gen Z creators. 
                Transform your content into scroll-stopping masterpieces.
                  </motion.p>
                  <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" 1,="" 0="" transition="{{" delay:="" 0.5="" classname="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                    <link to="/contact" />
                    <glowbutton size="lg">
                      Get Started
                      <arrowright classname="w-5 h-5">
                      </arrowright>
                    </glowbutton>
                    <link to="/portfolio" />
                    <glowbutton variant="secondary" size="lg">
                      <play classname="w-5 h-5">
                        View Portfolio
                      </play>
                    </glowbutton>
                  </motion.div>
                  \{/* Stats */\}
                  <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" 1,="" 0="" transition="{{" delay:="" 0.6="" classname="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-12">
                    \{stats.map((stat, index) => (
                    <div key="{index}" classname="text-center lg:text-left">
                      <div classname="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                        \{stat.value\}
                      </div>
                      <div classname="text-sm text-gray-500">
                        \{stat.label\}
                      </div>
                    </div>
                    ))\}
                  </motion.div>
                </motion.div>
                \{/* Right Content - Reels Player */\}
                <motion.div initial="{{" opacity:="" 0,="" x:="" 50="" }}="" animate="{{" 1,="" 0="" transition="{{" duration:="" 0.8,="" delay:="" 0.3="" classname="hidden lg:block">
                  <reelsplayer>
                  </reelsplayer>
                </motion.div>
              </div>
            </div>
            \{/* Scroll Indicator */\}
            <motion.div initial="{{" opacity:="" 0="" }}="" animate="{{" 1="" transition="{{" delay:="" 1.5="" classname="absolute bottom-8 left-1/2 -translate-x-1/2">
              <motion.div animate="{{" y:="" [0,="" 10,="" 0]="" }}="" transition="{{" repeat:="" infinity,="" duration:="" 2="" classname="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
                <div classname="w-1 h-2 bg-white/50 rounded-full">
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  </section>
  \{/* Features Section */\}
  <section classname="py-20 px-4 relative">
    <div classname="max-w-7xl mx-auto">
      <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-16">
        <h2 classname="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
          Why Creators Choose\{' '\}
          <span classname="bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
            EditSpace
          </span>
        </h2>
        <p classname="text-gray-400 text-lg max-w-2xl mx-auto">
          We understand the hustle. Fast delivery, trending styles, and prices that don't break the bank.
        </p>
      </motion.div>
      <div classname="grid md:grid-cols-3 gap-6">
        \{features.map((feature, index) => (
        <motion.div key="{index}" initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.1="" whilehover="{{" -10,="" scale:="" 1.02="" classname="group relative p-8 bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-2xl hover:border-cyan-500/30 transition-all duration-500">
          \{/* Glow effect on hover */\}
          <div classname="{`absolute" inset-0="" bg-gradient-to-r="" ${feature.color}="" opacity-0="" group-hover:opacity-5="" rounded-2xl="" transition-opacity="" duration-500`}="">
            <div classname="{`w-14" h-14="" rounded-xl="" bg-gradient-to-r="" ${feature.color}="" flex="" items-center="" justify-center="" mb-6="" group-hover:scale-110="" transition-transform="" duration-300`}="">
              <feature.icon classname="w-7 h-7 text-white">
              </feature.icon>
            </div>
            <h3 classname="text-xl font-bold text-white mb-3">
              \{feature.title\}
            </h3>
            <p classname="text-gray-400">
              \{feature.description\}
            </p>
            ))\}
          </div>
        </motion.div>
      </div>
    </div>
  </section>
  \{/* Services Preview */\}
  <section classname="py-20 px-4 relative overflow-hidden">
    <div classname="absolute inset-0 bg-gradient-to-r from-cyan-500/5 via-purple-500/5 to-pink-500/5">
      <div classname="max-w-7xl mx-auto relative">
        <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-16">
          <h2 classname="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            Our\{' '\}
            <span classname="bg-gradient-to-r from-pink-400 to-orange-400 bg-clip-text text-transparent">
              Services
            </span>
          </h2>
        </motion.div>
        <div classname="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          \{[
              \{ title: 'Reels & Shorts Editing', emoji: '🎬', desc: 'Trending transitions, effects & music sync' \},
              \{ title: 'Thumbnail Design', emoji: '🖼️', desc: 'Click-worthy thumbnails that boost CTR' \},
              \{ title: 'Logo & Branding', emoji: '✨', desc: 'Memorable brand identity design' \},
              \{ title: 'Social Media Graphics', emoji: '📱', desc: 'Posts, stories & carousel designs' \},
              \{ title: 'Website Development', emoji: '🌐', desc: 'Modern, responsive websites' \},
              \{ title: 'Motion Graphics', emoji: '🎯', desc: 'Animated intros, outros & overlays' \},
            ].map((service, index) => (
          <motion.div key="{index}" initial="{{" opacity:="" 0,="" scale:="" 0.9="" }}="" whileinview="{{" 1,="" 1="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.05="" whilehover="{{" 1.05="" classname="group p-6 bg-black/50 border border-white/10 rounded-xl hover:border-purple-500/30 transition-all cursor-pointer">
            <div classname="text-4xl mb-4">
              \{service.emoji\}
            </div>
            <h3 classname="text-lg font-semibold text-white mb-2 group-hover:text-purple-400 transition-colors">
              \{service.title\}
            </h3>
            <p classname="text-gray-400 text-sm">
              \{service.desc\}
            </p>
          </motion.div>
          ))\}
        </div>
        <motion.div initial="{{" opacity:="" 0="" }}="" whileinview="{{" 1="" viewport="{{" once:="" true="" classname="text-center mt-12">
          <link to="/services" />
          <glowbutton variant="outline">
            View All Services
            <chevronright classname="w-5 h-5">
            </chevronright>
          </glowbutton>
        </motion.div>
      </div>
    </div>
  </section>
  \{/* Testimonials */\}
  <section classname="py-20 px-4">
    <div classname="max-w-7xl mx-auto">
      <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="text-center mb-16">
        <h2 classname="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
          What Creators\{' '\}
          <span classname="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
            Say
          </span>
        </h2>
      </motion.div>
      <div classname="grid md:grid-cols-3 gap-6">
        \{[
              \{
                name: 'Priya Sharma',
                handle: '@priyacreates',
                text: 'EditSpace transformed my content! My reels went from 1K to 50K views. The edits are 🔥',
                rating: 5,
              \},
              \{
                name: 'Arjun Das',
                handle: '@arjunvlogs',
                text: 'Super fast delivery and they actually understand Gen Z aesthetics. Highly recommend!',
                rating: 5,
              \},
              \{
                name: 'Sneha Roy',
                handle: '@snehalifestyle',
                text: 'Best investment for my brand. The thumbnails they designed increased my CTR by 40%!',
                rating: 5,
              \},
            ].map((testimonial, index) => (
        <motion.div key="{index}" initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" transition="{{" delay:="" index="" *="" 0.1="" classname="p-6 bg-gradient-to-b from-white/5 to-transparent border border-white/10 rounded-2xl">
          <div classname="flex gap-1 mb-4">
            \{[...Array(testimonial.rating)].map((_, i) => (
            <star key="{i}" classname="w-5 h-5 text-yellow-400 fill-yellow-400">
              ))\}
            </star>
          </div>
          <p classname="text-gray-300 mb-6">
            "\{testimonial.text\}"
          </p>
          <div>
            <p classname="text-white font-semibold">
              \{testimonial.name\}
            </p>
            <p classname="text-cyan-400 text-sm">
              \{testimonial.handle\}
            </p>
          </div>
        </motion.div>
        ))\}
      </div>
    </div>
  </section>
  \{/* CTA Section */\}
  <section classname="py-20 px-4 relative overflow-hidden">
    <div classname="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-pink-500/10">
      <div classname="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-purple-500/20 rounded-full blur-3xl">
        <motion.div initial="{{" opacity:="" 0,="" y:="" 30="" }}="" whileinview="{{" 1,="" 0="" viewport="{{" once:="" true="" classname="max-w-4xl mx-auto text-center relative">
          <h2 classname="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Ready to Level Up Your Content?
          </h2>
          <p classname="text-xl text-gray-400 mb-8">
            DM us on Instagram or drop us an email. Let's create something amazing together!
          </p>
          <div classname="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="https://instagram.com/editspace.in" target="_blank" rel="noopener noreferrer">
              <glowbutton size="lg">
                📱 DM on Instagram
              </glowbutton>
            </a>
            <link to="/contact" />
            <glowbutton variant="outline" size="lg">
              ✉️ Get a Quote
            </glowbutton>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
</div>
);
\}
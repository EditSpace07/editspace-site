import \{ useState, useRef \} from 'react';
import \{ motion, AnimatePresence \} from 'framer-motion';
import \{ Play, Heart, MessageCircle, Share2, Bookmark, Volume2, VolumeX, ChevronUp, ChevronDown \} from 'lucide-react';

interface Reel \{
  id: number;
  video: string;
  likes: string;
  comments: string;
  caption: string;
  author: string;
\}

const reels: Reel[] = [
  \{
    id: 1,
    video: '/videos/reel-demo-1.mp4',
    likes: '12.4K',
    comments: '234',
    caption: '✨ Smooth transitions that hit different #editspace #reels',
    author: '@editspace.in',
  \},
  \{
    id: 2,
    video: '/videos/reel-demo-2.mp4',
    likes: '8.7K',
    comments: '156',
    caption: '🎨 Color grading magic for your content #colorgrade',
    author: '@editspace.in',
  \},
];

export default function ReelsPlayer() \{
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [liked, setLiked] = useState
<number[]>
  ([]);
  const [saved, setSaved] = useState
  <number[]>
    ([]);
  const videoRef = useRef
    <htmlvideoelement>
      (null);

  const currentReel = reels[currentIndex];

  const togglePlay = () => \{
    if (videoRef.current) \{
      if (isPlaying) \{
        videoRef.current.pause();
      \} else \{
        videoRef.current.play();
      \}
      setIsPlaying(!isPlaying);
    \}
  \};

  const toggleMute = () => \{
    if (videoRef.current) \{
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    \}
  \};

  const nextReel = () => \{
    if (currentIndex < reels.length - 1) \{
      setCurrentIndex(currentIndex + 1);
    \}
  \};

  const prevReel = () => \{
    if (currentIndex > 0) \{
      setCurrentIndex(currentIndex - 1);
    \}
  \};

  const toggleLike = (id: number) => \{
    setLiked(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  \};

  const toggleSave = (id: number) => \{
    setSaved(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  \};

  return (
      <div classname="relative w-full max-w-[360px] mx-auto">
        \{/* Phone Frame */\}
        <div classname="relative bg-black rounded-[3rem] p-3 shadow-2xl shadow-purple-500/20 border-4 border-gray-800">
          \{/* Notch */\}
          <div classname="absolute top-4 left-1/2 -translate-x-1/2 w-24 h-6 bg-black rounded-full z-20">
            \{/* Screen */\}
            <div classname="relative aspect-[9/16] rounded-[2.5rem] overflow-hidden bg-gray-900">
              \{/* Video */\}
              <animatepresence mode="wait">
                <motion.div key="{currentReel.id}" initial="{{" opacity:="" 0="" }}="" animate="{{" 1="" exit="{{" classname="absolute inset-0">
                  <video ref="{videoRef}" src="{currentReel.video}" classname="w-full h-full object-cover" loop={true} muted="{isMuted}" autoPlay={true} playsinline="" onClick="{togglePlay}">
                  </video>
                </motion.div>
              </animatepresence>
              \{/* Gradient Overlays */\}
              <div classname="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60 pointer-events-none">
                \{/* Play/Pause Indicator */\}
                <animatepresence>
                  \{!isPlaying && (
                  <motion.div initial="{{" opacity:="" 0,="" scale:="" 0.5="" }}="" animate="{{" 1,="" 1="" exit="{{" classname="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div classname="w-20 h-20 bg-black/50 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <play classname="w-10 h-10 text-white ml-1" fill="white">
                      </play>
                    </div>
                  </motion.div>
                  )\}
                </animatepresence>
                \{/* Navigation Arrows */\}
                <div classname="absolute right-2 top-1/2 -translate-y-1/2 flex flex-col gap-2 z-10">
                  <button onClick="{prevReel}" disabled="{currentIndex" =="=" 0}="" classname="{`p-2" rounded-full="" bg-black="" 30="" backdrop-blur-sm="" transition-all="" ${currentindex="==" 0="" ?="" 'opacity-30'="" :="" 'hover:bg-black="" 50'}`}="">
                    <chevronup classname="w-5 h-5 text-white">
                    </chevronup>
                  </button>
                  <button onClick="{nextReel}" disabled="{currentIndex" =="=" reels.length="" -="" 1}="" classname="{`p-2" rounded-full="" bg-black="" 30="" backdrop-blur-sm="" transition-all="" ${currentindex="==" 1="" ?="" 'opacity-30'="" :="" 'hover:bg-black="" 50'}`}="">
                    <chevrondown classname="w-5 h-5 text-white">
                    </chevrondown>
                  </button>
                </div>
                \{/* Side Actions */\}
                <div classname="absolute right-3 bottom-24 flex flex-col items-center gap-5">
                  <button onClick="{()" =="">
                    toggleLike(currentReel.id)\}
              className="flex flex-col items-center gap-1 group"
            >
                    <motion.div whiletap="{{" scale:="" 1.3="" }}="" classname="{`p-2" rounded-full="" ${liked.includes(currentreel.id)="" ?="" 'text-pink-500'="" :="" 'text-white'}`}="">
                      <heart classname="w-7 h-7" fill="{liked.includes(currentReel.id)" ?="" 'currentcolor'="" :="" 'none'}="">
                      </heart>
                    </motion.div>
                    <span classname="text-white text-xs font-medium">
                      \{currentReel.likes\}
                    </span>
                  </button>
                  <button classname="flex flex-col items-center gap-1">
                    <div classname="p-2">
                      <messagecircle classname="w-7 h-7 text-white">
                      </messagecircle>
                    </div>
                    <span classname="text-white text-xs font-medium">
                      \{currentReel.comments\}
                    </span>
                  </button>
                  <button classname="flex flex-col items-center gap-1">
                    <div classname="p-2">
                      <share2 classname="w-7 h-7 text-white">
                      </share2>
                    </div>
                    <span classname="text-white text-xs font-medium">
                      Share
                    </span>
                  </button>
                  <button onClick="{()" =="">
                    toggleSave(currentReel.id)\}
              className="flex flex-col items-center gap-1"
            >
                    <motion.div whiletap="{{" scale:="" 1.2="" }}="" classname="p-2">
                      <bookmark classname="{`w-7" h-7="" ${saved.includes(currentreel.id)="" ?="" 'text-yellow-400'="" :="" 'text-white'}`}="" fill="{saved.includes(currentReel.id)" 'currentcolor'="" 'none'}="">
                      </bookmark>
                    </motion.div>
                  </button>
                  <button onClick="{toggleMute}" classname="p-2 rounded-full bg-black/30 backdrop-blur-sm">
                    \{isMuted ? (
                    <volumex classname="w-5 h-5 text-white">
                      ) : (
                      <volume2 classname="w-5 h-5 text-white">
                        )\}
                      </volume2>
                    </volumex>
                  </button>
                </div>
                \{/* Bottom Info */\}
                <div classname="absolute bottom-4 left-3 right-16">
                  <p classname="text-white font-semibold text-sm mb-1">
                    \{currentReel.author\}
                  </p>
                  <p classname="text-white/90 text-xs leading-relaxed">
                    \{currentReel.caption\}
                  </p>
                </div>
                \{/* Progress Dots */\}
                <div classname="absolute top-10 left-1/2 -translate-x-1/2 flex gap-1">
                  \{reels.map((_, index) => (
                  <div key="{index}" classname="{`h-1" rounded-full="" transition-all="" duration-300="" ${="" index="==" currentindex="" ?="" 'w-6="" bg-white'="" :="" 'w-1="" bg-white="" 40'="" }`}="">
                    ))\}
                  </div>
                </div>
              </div>
              \{/* Glow Effect */\}
              <div classname="absolute -inset-4 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20 blur-3xl -z-10 rounded-full">
              </div>
              );
\}
            </div>
          </div>
        </div>
      </div>
    </htmlvideoelement>
  </number[]>
</number[]>
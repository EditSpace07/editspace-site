import \{ useState \} from 'react';
import \{ Link, useLocation \} from 'react-router-dom';
import \{ motion, AnimatePresence \} from 'framer-motion';
import \{ Menu, X, Sparkles \} from 'lucide-react';

export default function Navbar() \{
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const links = [
    \{ path: '/', label: 'Home' \},
    \{ path: '/services', label: 'Services' \},
    \{ path: '/pricing', label: 'Pricing' \},
    \{ path: '/portfolio', label: 'Portfolio' \},
    \{ path: '/about', label: 'About' \},
    \{ path: '/contact', label: 'Contact' \},
  ];

  return (
<nav classname="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-xl border-b border-cyan-500/20">
  <div classname="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div classname="flex items-center justify-between h-16 md:h-20">
      <link to="/" classname="flex items-center gap-2 group" />
      <img src="/images/logo.png" alt="EditSpace" classname="w-10 h-10 md:w-12 md:h-12 rounded-lg" />
      <span classname="text-xl md:text-2xl font-bold bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent group-hover:from-pink-500 group-hover:to-cyan-400 transition-all duration-500">
        EditSpace
      </span>
      \{/* Desktop Navigation */\}
      <div classname="hidden md:flex items-center gap-1">
        \{links.map((link) => (
        <link key="{link.path}" to="{link.path}" classname="{`relative" px-4="" py-2="" text-sm="" font-medium="" transition-all="" duration-300="" rounded-lg="" group="" ${="" location.pathname="==" link.path="" ?="" 'text-cyan-400'="" :="" 'text-gray-300="" hover:text-white'="" }`}="" />
        \{link.label\}
                \{location.pathname === link.path && (
        <motion.div layoutid="navbar-indicator" classname="absolute inset-0 bg-cyan-500/10 border border-cyan-500/30 rounded-lg -z-10" transition="{{" type:="" 'spring',="" bounce:="" 0.2,="" duration:="" 0.6="" }}="">
          )\}
          <span classname="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-gradient-to-r from-cyan-400 to-purple-500 group-hover:w-full transition-all duration-300">
            ))\}
            <link to="/login" classname="ml-4 px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-full text-white font-semibold text-sm hover:shadow-lg hover:shadow-cyan-500/30 transition-all duration-300 hover:scale-105 flex items-center gap-2" />
            <sparkles classname="w-4 h-4">
              Login
            </sparkles>
          </span>
        </motion.div>
      </div>
      \{/* Mobile Menu Button */\}
      <button onClick="{()" =="">
        setIsOpen(!isOpen)\}
            className="md:hidden p-2 text-gray-300 hover:text-white transition-colors"
          >
            \{isOpen ?
        <x classname="w-6 h-6">
          :
          <menu classname="w-6 h-6">
            \}
          </menu>
        </x>
      </button>
    </div>
  </div>
  \{/* Mobile Navigation */\}
  <animatepresence>
    \{isOpen && (
    <motion.div initial="{{" opacity:="" 0,="" height:="" 0="" }}="" animate="{{" 1,="" 'auto'="" exit="{{" classname="md:hidden bg-black/95 backdrop-blur-xl border-b border-cyan-500/20">
      <div classname="px-4 py-4 space-y-2">
        \{links.map((link, index) => (
        <motion.div key="{link.path}" initial="{{" opacity:="" 0,="" x:="" -20="" }}="" animate="{{" 1,="" 0="" transition="{{" delay:="" index="" *="" 0.05="">
          <link to="{link.path}" onClick="{()" =="" />
          setIsOpen(false)\}
                    className=\{`block px-4 py-3 rounded-lg text-base font-medium transition-all $\{
                      location.pathname === link.path
                        ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                        : 'text-gray-300 hover:bg-white/5 hover:text-white'
                    \}`\}
                  >
                    \{link.label\}
        </motion.div>
        ))\}
        <motion.div initial="{{" opacity:="" 0,="" x:="" -20="" }}="" animate="{{" 1,="" 0="" transition="{{" delay:="" links.length="" *="" 0.05="">
          <link to="/login" onClick="{()" =="" />
          setIsOpen(false)\}
                  className="block mt-4 px-4 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-lg text-white font-semibold text-center"
                >
                  Login / Sign Up
        </motion.div>
      </div>
    </motion.div>
    )\}
  </animatepresence>
</nav>
);
\}
import \{ useEffect, useRef \} from 'react';

export default function ThreeBackground() \{
  const canvasRef = useRef
<htmlcanvaselement>
  (null);

  useEffect(() => \{
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let particles: Particle[] = [];

    const resize = () => \{
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    \};

    class Particle \{
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      color: string;
      opacity: number;

      constructor() \{
        this.x = Math.random() * canvas!.width;
        this.y = Math.random() * canvas!.height;
        this.size = Math.random() * 2 + 0.5;
        this.speedX = (Math.random() - 0.5) * 0.5;
        this.speedY = (Math.random() - 0.5) * 0.5;
        const colors = ['#06b6d4', '#8b5cf6', '#ec4899', '#3b82f6'];
        this.color = colors[Math.floor(Math.random() * colors.length)];
        this.opacity = Math.random() * 0.5 + 0.2;
      \}

      update() \{
        this.x += this.speedX;
        this.y += this.speedY;

        if (this.x > canvas!.width) this.x = 0;
        if (this.x < 0) this.x = canvas!.width;
        if (this.y > canvas!.height) this.y = 0;
        if (this.y < 0) this.y = canvas!.height;
      \}

      draw() \{
        if (!ctx) return;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.globalAlpha = this.opacity;
        ctx.fill();
        ctx.globalAlpha = 1;
      \}
    \}

    const init = () => \{
      particles = [];
      const particleCount = Math.min(100, Math.floor((canvas.width * canvas.height) / 15000));
      for (let i = 0; i < particleCount; i++) \{
        particles.push(new Particle());
      \}
    \};

    const connectParticles = () => \{
      if (!ctx) return;
      for (let i = 0; i < particles.length; i++) \{
        for (let j = i + 1; j < particles.length; j++) \{
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 150) \{
            ctx.beginPath();
            ctx.strokeStyle = particles[i].color;
            ctx.globalAlpha = (1 - distance / 150) * 0.15;
            ctx.lineWidth = 0.5;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
            ctx.globalAlpha = 1;
          \}
        \}
      \}
    \};

    const animate = () => \{
      if (!ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      particles.forEach(particle => \{
        particle.update();
        particle.draw();
      \});

      connectParticles();
      animationId = requestAnimationFrame(animate);
    \};

    resize();
    init();
    animate();

    window.addEventListener('resize', () => \{
      resize();
      init();
    \});

    return () => \{
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
    \};
  \}, []);

  return (
  <canvas ref="{canvasRef}" classname="fixed inset-0 -z-10 bg-black">
    );
\}
  </canvas>
</htmlcanvaselement>
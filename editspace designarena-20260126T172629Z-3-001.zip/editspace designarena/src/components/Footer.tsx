import \{ Link \} from 'react-router-dom';
import \{ Instagram, Mail, MapPin, Heart, ArrowUpRight \} from 'lucide-react';

export default function Footer() \{
  return (
<footer classname="relative bg-black border-t border-cyan-500/20">
  \{/* Gradient overlay */\}
  <div classname="absolute inset-0 bg-gradient-to-t from-purple-900/10 to-transparent pointer-events-none">
    <div classname="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      <div classname="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
        \{/* Brand */\}
        <div classname="lg:col-span-1">
          <link to="/" classname="flex items-center gap-2 mb-4" />
          <img src="/images/logo.png" alt="EditSpace" classname="w-10 h-10 rounded-lg" />
          <span classname="text-xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
            EditSpace
          </span>
          <p classname="text-gray-400 text-sm leading-relaxed mb-4">
            Premium video editing, graphic design & web development for Gen Z creators. Based in Kolkata, serving creators worldwide.
          </p>
          <div classname="flex items-center gap-2 text-gray-400 text-sm">
            <mappin classname="w-4 h-4 text-cyan-400">
              <span>
                Kolkata, West Bengal, India
              </span>
            </mappin>
          </div>
        </div>
        \{/* Quick Links */\}
        <div>
          <h4 classname="text-white font-semibold mb-4 flex items-center gap-2">
            <span classname="w-2 h-2 bg-cyan-400 rounded-full">
              Quick Links
            </span>
          </h4>
          <ul classname="space-y-2">
            \{['Home', 'Services', 'Pricing', 'Portfolio', 'About', 'Contact'].map((item) => (
            <li key="{item}">
              <link to="{item" =="=" 'home'="" ?="" '="" :="" `="" ${item.tolowercase()}`}="" classname="text-gray-400 hover:text-cyan-400 transition-colors text-sm flex items-center gap-1 group" />
              \{item\}
              <arrowupright classname="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity">
              </arrowupright>
            </li>
            ))\}
          </ul>
        </div>
        \{/* Services */\}
        <div>
          <h4 classname="text-white font-semibold mb-4 flex items-center gap-2">
            <span classname="w-2 h-2 bg-purple-400 rounded-full">
              Services
            </span>
          </h4>
          <ul classname="space-y-2">
            \{[
                'Instagram Reels Editing',
                'YouTube Shorts',
                'Thumbnail Design',
                'Logo & Branding',
                'Website Development',
                'Motion Graphics',
              ].map((item) => (
            <li key="{item}">
              <link to="/services" classname="text-gray-400 hover:text-purple-400 transition-colors text-sm" />
              \{item\}
            </li>
            ))\}
          </ul>
        </div>
        \{/* Connect */\}
        <div>
          <h4 classname="text-white font-semibold mb-4 flex items-center gap-2">
            <span classname="w-2 h-2 bg-pink-400 rounded-full">
              Let's Connect
            </span>
          </h4>
          <div classname="space-y-3">
            <a href="https://instagram.com/editspace.in" target="_blank" rel="noopener noreferrer" classname="flex items-center gap-3 p-3 bg-gradient-to-r from-pink-500/10 to-purple-500/10 border border-pink-500/20 rounded-lg hover:border-pink-500/40 transition-all group">
              <instagram classname="w-5 h-5 text-pink-400">
                <div>
                  <span classname="text-white text-sm font-medium">
                    @editspace.in
                  </span>
                  <p classname="text-gray-400 text-xs">
                    DM for quick quotes
                  </p>
                </div>
              </instagram>
            </a>
            <a href="mailto:hello@editspace.in" classname="flex items-center gap-3 p-3 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-lg hover:border-cyan-500/40 transition-all group">
              <mail classname="w-5 h-5 text-cyan-400">
                <div>
                  <span classname="text-white text-sm font-medium">
                    hello@editspace.in
                  </span>
                  <p classname="text-gray-400 text-xs">
                    Email us anytime
                  </p>
                </div>
              </mail>
            </a>
          </div>
        </div>
      </div>
      \{/* Bottom Bar */\}
      <div classname="mt-12 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
        <p classname="text-gray-400 text-sm text-center md:text-left">
          © \{new Date().getFullYear()\} EditSpace. All rights reserved.
        </p>
        <p classname="text-gray-400 text-sm flex items-center gap-1">
          Made with
          <heart classname="w-4 h-4 text-pink-500 fill-pink-500">
            in Kolkata
          </heart>
        </p>
      </div>
    </div>
  </div>
</footer>
);
\}
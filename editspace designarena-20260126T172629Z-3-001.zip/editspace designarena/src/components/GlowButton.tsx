import \{ motion \} from 'framer-motion';
import type \{ ReactNode \} from 'react';

interface GlowButtonProps \{
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  type?: 'button' | 'submit';
  disabled?: boolean;
\}

export default function GlowButton(\{
  children,
  onClick,
  variant = 'primary',
  size = 'md',
  className = '',
  type = 'button',
  disabled = false,
\}: GlowButtonProps) \{
  const baseStyles = 'relative font-semibold rounded-full transition-all duration-300 overflow-hidden group';
  
  const variants = \{
    primary: 'bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 text-white hover:shadow-lg hover:shadow-cyan-500/30',
    secondary: 'bg-white/10 backdrop-blur-sm text-white border border-white/20 hover:bg-white/20 hover:border-white/40',
    outline: 'bg-transparent text-cyan-400 border-2 border-cyan-400 hover:bg-cyan-400/10 hover:shadow-lg hover:shadow-cyan-400/20',
  \};

  const sizes = \{
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg',
  \};

  return (
<motion.button type="{type}" onClick="{onClick}" disabled="{disabled}" whilehover="{{" scale:="" 1.05="" }}="" whiletap="{{" 0.95="" classname="{`${baseStyles}" ${variants[variant]}="" ${sizes[size]}="" ${classname}="" ${disabled="" ?="" 'opacity-50="" cursor-not-allowed'="" :="" ''}`}="">
  \{/* Glow effect */\}
      \{variant === 'primary' && (
  <span classname="absolute inset-0 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 opacity-0 group-hover:opacity-50 blur-xl transition-opacity duration-300">
    )\}
      
      \{/* Shimmer effect */\}
    <span classname="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent">
      <span classname="relative z-10 flex items-center justify-center gap-2">
        \{children\}
      </span>
    </span>
  </span>
</motion.button>
);
\}